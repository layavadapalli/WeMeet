package com.example.we_meet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
