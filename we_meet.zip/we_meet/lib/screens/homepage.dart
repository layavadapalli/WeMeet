import 'package:flutter/material.dart';

class Homepage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFccd5ae),
        body: Center(
          child: Container(
            color: Colors.transparent,
            child: Text("Welcome User!",
              style: TextStyle(
                fontSize: 30.0,
                color: Colors.black,
              ),
            ),
          ),
        )
    );
  }
}