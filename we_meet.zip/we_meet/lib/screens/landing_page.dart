import 'package:flutter/material.dart';
import 'package:we_meet/screens/log_in.dart';
import 'package:we_meet/screens/sign_up.dart';


class LandingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFccd5ae),
        body: Container(
          margin: EdgeInsets.all(50),
          padding: EdgeInsets.only(top: 100),
          alignment: Alignment.center,
          height: 750,
          width: 300,
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                  'assets/logo-transparent.png'
              ),
            ),
          ),
            child: Stack(
              children: [
                Positioned(
                  child:Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget> [
                        ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(builder: (context)=>LogIn()));
                            },
                            style:
                            ElevatedButton.styleFrom
                              (
                              primary: Color(0xFF84a98c),
                              ),
                            child: const Text(
                                'Log In',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 25,
                                )
                            )
                        ),

                        const SizedBox(height: 30),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom
                            (
                            primary: Color(0xFF84a98c),
                          ),
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>SignUp())
                            );
                          },
                          child: const Text(
                              'Sign Up',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 25,
                              )),
                        ),


                      ]

                  ),
                  left: 100.0,
                  top: 400.0,
                )
              ],

            )

        )
        );
  }

  }
