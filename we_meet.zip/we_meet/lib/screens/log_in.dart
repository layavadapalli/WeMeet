import 'package:flutter/material.dart';
import 'package:we_meet/screens/homepage.dart';
import 'package:we_meet/screens/sign_up.dart';


class LogIn extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFccd5ae),
        body: Container(
            alignment: Alignment.center,
            child: Stack(
              children: [
                Positioned(
                  child:Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget> [
                        Text("Log In to your account!",
                          style:
                          TextStyle(
                              fontSize: 30,
                              color: Colors.black,
                          ),
                        ),
                        ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Homepage()));
                            },
                            style:
                            ElevatedButton.styleFrom
                              (
                              primary: Color(0xFF84a98c),
                            ),
                            child: const Text(
                                'Continue',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 25,
                                )
                            )
                        )


                      ]

                  ),
                  left: 50,
                  top: 400.0,
                )
              ],

            )

        )

    );
  }
}